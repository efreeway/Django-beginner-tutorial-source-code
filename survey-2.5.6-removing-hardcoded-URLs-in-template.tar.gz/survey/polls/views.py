from django.shortcuts import get_object_or_404,render
from django.http import HttpResponse
#from django.http import Http404

# Create your views here.
from .models import Question
from django.template import loader

def  index(request):
	# #:Original: only told where you arefhjq
	# return HttpResponse("Hello world! you/re in polls' index!")

	# #actually do something
	# latest_question_list = Question.objects.order_by('-pub_date')[:5]
	# output = ','.join([q.question_text for q in latest_question_list])
	# return HttpResponse(output)

	# #actually do something with a template
 #    latest_question_list=Question.objects.order_by('-pub_date')[:5]
 #    template = loader.get_template('polls/index.html')hnqt
 #    context = {'latest_question_list': latest_question_list}
 #    return HttpResponse(template.render(context, request))

	#actually do something with a template and a shortcut: render()
    latest_question_list=Question.objects.order_by('-pub_date')[:5]
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/index.html', context)


def detail(request,question_id):
	# #raising a 404 error
	# try:
	#     question = Question.objects.get(pk=question_id)
	# except Question.DoesNotExist:
	#     raise Http404('Question Does not Exist!')
	# return render(request,'polls/detail.html',{'question':question})

	# raising a 404 error with a shortcut
	question = get_object_or_404(Question, pk=question_id)
	return render(request, 'polls/detail.html', {'question':question})


def results(request,question_id):
	response = "Your are looking for the result of question %s. "
	return HttpResponse(response % question_id)

def vote(request,question_id):
	return HttpResponse("You are voting on question %s." % question_id)