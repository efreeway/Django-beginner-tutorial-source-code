from django.test import TestCase

# Create your tests here.
from .models import Question
import datetime
from django.utils import timezone

class QuestionClassTests(TestCase):

	def  test_was_published_recently_with_future_question(self):
		time = timezone.now() + datetime.timedelta(days=30)
		future_question = Question(pub_date=time)
		self.assertIs(future_question.was_published_recently(), False)

	# """docstring for Pub_Time_Test"""
	# def __init__(self, arg):
	# 	super(Pub_Time_Test, self).__init__()
	# 	self.arg = arg
	# 	