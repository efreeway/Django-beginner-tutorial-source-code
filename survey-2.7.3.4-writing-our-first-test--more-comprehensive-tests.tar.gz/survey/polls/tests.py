from django.test import TestCase

# Create your tests here.
from .models import Question
import datetime
from django.utils import timezone

class QuestionClassTests(TestCase):

	def  test_was_published_recently_with_future_question(self):
		time = timezone.now() + datetime.timedelta(days=30)
		future_question = Question(pub_date=time)
		self.assertIs(future_question.was_published_recently(), False)

	def  test_was_published_recently_with_old_question(self):
		time = timezone.now() - datetime.timedelta(days=1, seconds=1)
		old_question = Question(pub_date=time)
		self.assertIs(old_question.was_published_recently(), False)

	def  test_was_published_recently_with_recent_question(self):
		# both timedalta(days=1, seconds=-1) and timedelta(hours=23, minutes=59, seconds=59) are OK!
		#time = timezone.now() - datetime.timedelta(days=1, seconds=-1)
		time = timezone.now() - datetime.timedelta(hours=23, minutes=59, seconds=59)
		recent_question = Question(pub_date=time)
		self.assertIs(recent_question.was_published_recently(), True)


	# """docstring for Pub_Time_Test"""
	# def __init__(self, arg):
	# 	super(Pub_Time_Test, self).__init__()
	# 	self.arg = arg
	# 	